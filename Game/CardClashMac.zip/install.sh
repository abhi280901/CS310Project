cd AI
chmod 777 tor.sh
pip3 install torch
pip3 install numpy
pip3 install pandas
pip3 install utils
pip3 install -U nltk
pip3 install openpyxl 
cd ..
chmod 777 mynltk.py
./mynltk.py