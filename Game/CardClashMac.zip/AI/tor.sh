cd AI
python3 main.py